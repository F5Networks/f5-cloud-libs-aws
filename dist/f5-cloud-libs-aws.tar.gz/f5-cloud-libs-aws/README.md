# AWS implementation of f5-cloud-libs autoscale code
